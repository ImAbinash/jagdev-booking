// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
   firebaseConfig : {
    apiKey: "AIzaSyA1gWkS5EkbyQx8SOYLxh9DBDfOQk3R0E0",
    authDomain: "jscybercafe2021-f70a0.firebaseapp.com",
    projectId: "jscybercafe2021-f70a0",
    storageBucket: "jscybercafe2021-f70a0.appspot.com",
    messagingSenderId: "943656543802",
    appId: "1:943656543802:web:fad459588a6461c1df3703",
    measurementId: "G-3J9JK19MP2"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
