export const environment = {
  production: true,
  firebaseConfig : {
    apiKey: "AIzaSyA1gWkS5EkbyQx8SOYLxh9DBDfOQk3R0E0",
    authDomain: "jscybercafe2021-f70a0.firebaseapp.com",
    projectId: "jscybercafe2021-f70a0",
    storageBucket: "jscybercafe2021-f70a0.appspot.com",
    messagingSenderId: "943656543802",
    appId: "1:943656543802:web:fad459588a6461c1df3703",
    measurementId: "G-3J9JK19MP2"
  }
};
