import { Component, ElementRef, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import * as moment from 'moment';
import { AdminService } from '../services/admin.service';
import { NotificationService } from '../services/notification.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.scss']
})
export class AdminComponent implements OnInit {


  @ViewChild('authBtn') authBtn!: ElementRef<HTMLElement>;
  @ViewChild('btnModalClose') btnModalClose!: ElementRef<HTMLElement>;


  filterTerm!: string;

  slotsOnDate:any = []

  atuhId: {
    userId: string
  };
  isAuthenticated: boolean = false;




  eachSlotDurationInMin = 10;

  firstHalfStartHour = 8;
  firstHalfStartMin = 30;
  firstHalfDurationInMin = 5 * 60;


  secondHalfStartHour = 14;
  secondHalfStartMin = 30;
  secondHalfDurationInMin = 2.5 * 60;

  slots: any = [];
  slotObj !: {
    startHour: number,
    startMin: number,
    endHour: number,
    endMin: number
  };
selectedDate!:string;



  constructor(private adminService: AdminService,
    private notificationService: NotificationService) {
    this.atuhId = {
      userId: ''
    };
    this.isAuthenticated = false;
   
  }

  ngAfterViewInit() {
    this.getUserDetailsFromStorage();
    if (!this.isAuthenticated) {
      let el: HTMLElement = this.authBtn.nativeElement;
      console.log(el);
      el.click();
    }
  }
  ngOnInit(): void {
    for (let i = 0; i < 5; i++) {
      let date = moment().add(i, 'days').format("DD-MM-YYYY");
      this.slotsOnDate.push(
        {
          'CurrentDate':date
        }
      )
    }

  }

  getAuthUserDetails() {
    this.adminService.getUserDetails(this.atuhId).subscribe(data => {
      console.log("Auth details: ", data)
      if (data.length > 0) {
        this.notificationService.showSuccess("Authenticated successfully!");
        this.atuhId = {
          userId: ''
        };
        this.isAuthenticated = true;

        let el: HTMLElement = this.btnModalClose.nativeElement;
        console.log(el);
        el.click();


        localStorage.setItem("AUTH_USER", data[0]);


      } else {
        this.isAuthenticated = false;
        this.notificationService.showError("Authenticated failed!");
        this.atuhId = {
          userId: ''
        };
      }
    });
  }

  getUserDetailsFromStorage() {
    const user = localStorage.getItem("AUTH_USER");
    
    if(user != undefined || user != null){
      this.isAuthenticated = true;
    }else{
      this.isAuthenticated =false;
    }
  }





  generateSlot(date:string) {
    this.slots=[];
    this.getSlot(this.firstHalfStartHour, this.firstHalfStartMin, this.firstHalfDurationInMin);
    this.getSlot(this.secondHalfStartHour, this.secondHalfStartMin, this.secondHalfDurationInMin);
    this.selectedDate = date;
  }

  getSlot(hr: number, min: number, duration: number) {
    let startHrPointer = hr;
    let startminPointer = min;
    let endHrPointer = hr;
    let endminPointer = min;
    let incrementHr = false;
    for (let i = 0, j = 0; i < duration; i = i + 10, j++) {
      startminPointer = endminPointer;
      endminPointer = endminPointer + 10;

      if (endminPointer == 60) {
        endHrPointer = endHrPointer + 1;
        endminPointer = 0;
        incrementHr = true;
      }


      this.slots.push(
        {
          startHour: startHrPointer,
          startMin: startminPointer,
          endHour: endHrPointer,
          endMin: endminPointer,
          isSelected:true
        }
      );
      if (incrementHr) {
        startHrPointer = endHrPointer;
        incrementHr = false;
      }

    }
  }
  saveSlot(){
    console.log(this.slots);
  }


  
}
