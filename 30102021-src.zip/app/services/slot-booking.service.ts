import { Injectable } from '@angular/core';
import { AngularFirestore, AngularFirestoreCollection } from '@angular/fire/compat/firestore';
import { BehaviorSubject, Observable, throwError } from 'rxjs';
import { AadharBookingDetailModel, ILinkVisibilityModel } from '../model/AdharDetails.model';
import { map, tap } from 'rxjs/operators';
import { NotificationService } from './notification.service';

@Injectable({
  providedIn: 'root'
})
export class SlotBookingService {
  private readonly aadharSlotDbPath = '/aadharslot/';
  private readonly aadharLinkDbPath = '/linkFlag'
  private adharBookingSlotSubject = new BehaviorSubject<AadharBookingDetailModel | null>(null);
  aadharBookingSlotObservable$: Observable<AadharBookingDetailModel | null>;

  showSlotBookinglinkSubject = new BehaviorSubject<boolean>(false);
  showSlotBookingObservable$: Observable<boolean>;
  aadhaarSlotRef: any;
  aadharLinkRef: any;


  constructor(private firestore: AngularFirestore,private notificatioService:NotificationService) {
    this.aadhaarSlotRef = this.firestore.collection(this.aadharSlotDbPath);
    this.aadharLinkRef = this.firestore.collection(this.aadharLinkDbPath);

    this.aadharBookingSlotObservable$ = this.adharBookingSlotSubject.asObservable();
    this.showSlotBookingObservable$ = this.showSlotBookinglinkSubject.asObservable();

    this.getAadharBookinglink();
    console.log("getAadharBookingSlotDetails called!");
    this.getAadharBookingSlotDetails();
  }


  getAadharBookinglink() {
    const aadharLinkSubscription = this.firestore.collection<ILinkVisibilityModel>(this.aadharLinkDbPath, ref =>
      ref.where('label', '==', "aadhar"))
      .valueChanges().pipe(
        map((data) => data
        ),
        tap((data) => {
          this.showSlotBookinglinkSubject.next(data[0].value);
        })
      );
    aadharLinkSubscription.subscribe();
  }
  getAadharBookingSlotDetails() {



    let todaysDateInMilisecond = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate()).getTime();


    this.firestore.collection<any>(this.aadharSlotDbPath+todaysDateInMilisecond+"/10-10/").snapshotChanges().pipe(
      map((data)=>{
        console.log("Data: "+ data);
      })
    ).subscribe();


  }
  saveAadharBookedSlot(slot: any) {

    console.log("Aadhaar service");
    console.log(slot);

    let id = slot.SelectedDateInMilisecond.toString();

    this.aadhaarSlotRef.doc(id).collection(slot.StartTimeInHr + "-" + slot.StartTimeInMin).doc().set({
      startTimeInHr: slot.StartTimeInHr,
      startTimeInMin: slot.StartTimeInMin,
      endTimeInHr: slot.EndTimeInHr,
      endTimeInMin: slot.EndTimeINMin,
      aadhaarNumber: slot.AadharNumber,
      userName: slot.UserName,
      mobileNumber: slot.MobileNumber,
      status: 'booked'
    }).then((data:any)=>{
      this.notificatioService.showSuccess("Slot booked successfully!");
    }).catchError((error:any)=>{
      this.notificatioService.showError("An error occurred, Please contact admin.");
    });


  }






}
