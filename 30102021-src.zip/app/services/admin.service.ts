import { Injectable } from '@angular/core';
import { AngularFirestore } from '@angular/fire/compat/firestore';
import { BehaviorSubject, Observable } from 'rxjs';
import { map, tap } from 'rxjs/operators';
import { AuthUserModel } from '../model/AdharDetails.model';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  private readonly authInfoDbPath = '/authInfo/';
  // private authInfoSubject = new BehaviorSubject<AuthUserModel|null>(null);
  // authInfoObservable :Observable<AuthUserModel|null>;
  authUserRef: any;
  constructor(private firestore: AngularFirestore) {
    //this.authInfoObservable = this.authInfoSubject.asObservable();
    this.authUserRef = this.firestore.collection(this.authInfoDbPath);
  }
  getUserDetails(userDetails: { userId: string }): Observable<any> {


    return this.firestore.collection<any>(this.authInfoDbPath, ref =>
      ref.where('userId', '==', userDetails.userId))
      .valueChanges().pipe(
        map((data) => data
        ));
  }






  
}
