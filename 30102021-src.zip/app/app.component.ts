import { Component } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { SlotBookingService } from './services/slot-booking.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {


  showBookingLink$:Observable<boolean>
  title = 'JS CyberCafe';
  constructor(private slotBookingService: SlotBookingService) {
    // this.slotBookingService.showSlotBookingObservable$.subscribe(data => {
    //   console.log("All subscribed data");
    //   console.log(data);
    // })
    this.showBookingLink$ = this.slotBookingService.showSlotBookingObservable$;
  }
}
