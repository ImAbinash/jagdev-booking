import { Component, OnInit } from '@angular/core';
import { NgbDate, NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { AadharBookingDetailModel, SelectedSlotModel } from '../model/AdharDetails.model';
import { NotificationService } from '../services/notification.service';
import { SlotBookingService } from '../services/slot-booking.service';

@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.scss']
})
export class BookingComponent implements OnInit {

  showAdharMorquee = false;
  dateModel !: NgbDateStruct;
  minDateObj: NgbDate;
  maxDateObj: NgbDate;

  formShow: boolean = false;


  // first half
  eachSlotDurationInMin = 10;

  firstHalfStartHour = 8;
  firstHalfStartMin = 30;
  firstHalfDurationInMin = 5 * 60;


  secondHalfStartHour = 14;
  secondHalfStartMin = 30;
  secondHalfDurationInMin = 2.5 * 60;


  selectedSlot: any = [];
  leftItemIndex = 0;
  rightItemIndex = 8;

  slots: any = [];
  slotObj !: {
    startHour: number,
    startMin: number,
    endHour: number,
    endMin: number
  };




  selectedSlotForBooking = {
    StartTimeInHr: 0,
    StartTimeInMin: 0,
    EndTimeInHr: 0,
    EndTimeINMin: 0,
    SelectedDateInMilisecond: 0,
    AadharNumber: '',
    UserName: '',
    MobileNumber: '',
    // BookedBy: "Admin|Self"
  };


  constructor(private slotBookingService: SlotBookingService, private notifcationService: NotificationService) {

    let year = new Date().getFullYear();
    let month = new Date().getMonth() + 1;
    let date = new Date().getDate();

    this.minDateObj = new NgbDate(year, month, date);
    this.maxDateObj = new NgbDate(year, month, date + 1);


  }


  // {year: 2021, month: 10, day: 14}
  ngOnInit(): void {

   // this.generateSlot();

  }
  toggleBookingFormVisibility(slot: any) {
    this.formShow = !this.formShow;
    if (this.formShow) {
      this.selectedSlotForBooking.StartTimeInHr = slot.startHour;
      this.selectedSlotForBooking.StartTimeInMin = slot.startMin;
      this.selectedSlotForBooking.EndTimeInHr = slot.endHour;
      this.selectedSlotForBooking.EndTimeINMin = slot.endMin;



    } else {

    }

  }

  /*
  generateSlot() {
    this.getSlot(this.firstHalfStartHour, this.firstHalfStartMin, this.firstHalfDurationInMin);



    this.getSlot(this.secondHalfStartHour, this.secondHalfStartMin, this.secondHalfDurationInMin);

    // this.selectedSlot = this.slots.splice(this.leftItemIndex, this.rightItemIndex);


    for (let i = this.leftItemIndex; i < (this.rightItemIndex - this.leftItemIndex); i++) {
      this.selectedSlot.push(
        { ...this.slots[i] }
      );
    }


  }

  getSlot(hr: number, min: number, duration: number) {
    let startHrPointer = hr;
    let startminPointer = min;
    let endHrPointer = hr;
    let endminPointer = min;
    let incrementHr = false;
    for (let i = 0, j = 0; i < duration; i = i + 10, j++) {
      startminPointer = endminPointer;
      endminPointer = endminPointer + 10;

      if (endminPointer == 60) {
        endHrPointer = endHrPointer + 1;
        endminPointer = 0;
        incrementHr = true;
      }


      this.slots.push(
        {
          startHour: startHrPointer,
          startMin: startminPointer,
          endHour: endHrPointer,
          endMin: endminPointer
        }
      );
      if (incrementHr) {
        startHrPointer = endHrPointer;
        incrementHr = false;
      }

    }
  }
*/
  showSlot(direction: string) {
    if (direction === "left") {
      if (this.leftItemIndex > 0) {
        this.leftItemIndex--;
        this.rightItemIndex--;
      }
    } else if (direction === "right") {
      if (this.rightItemIndex < this.slots.length) {
        this.leftItemIndex++;
        this.rightItemIndex++;
      }
    }
    this.selectedSlot = [];

    for (let i = this.leftItemIndex; i < this.rightItemIndex; i++) {
      this.selectedSlot.push(
        { ...this.slots[i] }
      );
    }

  }

  bookAnAppointment() {
    this.selectedSlotForBooking.SelectedDateInMilisecond = new Date(this.dateModel.year,this.dateModel.month,this.dateModel.day).getTime();
    if (this.selectedSlotForBooking.SelectedDateInMilisecond == 0 || this.selectedSlotForBooking.SelectedDateInMilisecond == undefined || isNaN(this.selectedSlotForBooking.SelectedDateInMilisecond))  {
      this.notifcationService.showError("Select date for booking");
      return;
    } else if (this.selectedSlotForBooking.UserName == "" || this.selectedSlotForBooking.UserName == undefined) {
      this.notifcationService.showError("Please fill aadhaar number");
      return;
    } else if (this.selectedSlotForBooking.AadharNumber == "" || this.selectedSlotForBooking.AadharNumber == undefined) {
      this.notifcationService.showError("Please fill aadhaar number");
      return;
    } else if (this.selectedSlotForBooking.MobileNumber == "" || this.selectedSlotForBooking.MobileNumber == undefined) {
      this.notifcationService.showError("Please fill mobile number");
      return;
    }


    if (this.dateModel != undefined) {
      this.selectedSlotForBooking.SelectedDateInMilisecond = new Date(this.dateModel.year, this.dateModel.month, this.dateModel.day).getTime();

    }
    console.log(this.selectedSlotForBooking);

    this.slotBookingService.saveAadharBookedSlot(this.selectedSlotForBooking);

  }



}
