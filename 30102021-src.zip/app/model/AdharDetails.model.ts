export interface AadharBookingDetailModel {
    AadharNumber: string;
    UserName: string;
    MobileNumber: string;
    BookedBy:"Admin|Self"
}

export interface ILinkVisibilityModel{
    label:string;
    value:boolean;
}

export interface SelectedSlotModel{
    StartTimeInHr:number,
    StartTimeInMin:number,
    EndTimeInHr:number,
    EndTimeINMin:number,
    SelectedDate: string,
    Member:Array<AadharBookingDetailModel>
}

export interface AuthUserModel{
    user:String;
}